﻿namespace Capa_Presentación
{
    partial class Pantalla_Crear_Factura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.label14 = new System.Windows.Forms.Label();
            this.txtMovilCrearFactura = new System.Windows.Forms.TextBox();
            this.cmbDistrito = new System.Windows.Forms.ComboBox();
            this.cmbCantón = new System.Windows.Forms.ComboBox();
            this.cmbProvincia = new System.Windows.Forms.ComboBox();
            this.txtCorreoCrearFactura = new System.Windows.Forms.TextBox();
            this.txtNombreCrearFacutra = new System.Windows.Forms.TextBox();
            this.txtIdCrearCliente = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnEnviarFactura = new System.Windows.Forms.Button();
            this.dgvProductosAgregados = new System.Windows.Forms.DataGridView();
            this.Producto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Precio = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btnAgregarProducto = new System.Windows.Forms.Button();
            this.txtTotalFactura = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtCantidadFactura = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtCategoriaFactura = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtPrecioFactura = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txtProductoFactura = new System.Windows.Forms.TextBox();
            this.txtCodigoCerarFactura = new System.Windows.Forms.TextBox();
            this.btnMostrarTablaFactura = new System.Windows.Forms.Button();
            this.dgvProductos = new System.Windows.Forms.DataGridView();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductosAgregados)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker1);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.txtMovilCrearFactura);
            this.groupBox1.Controls.Add(this.cmbDistrito);
            this.groupBox1.Controls.Add(this.cmbCantón);
            this.groupBox1.Controls.Add(this.cmbProvincia);
            this.groupBox1.Controls.Add(this.txtCorreoCrearFactura);
            this.groupBox1.Controls.Add(this.txtNombreCrearFacutra);
            this.groupBox1.Controls.Add(this.txtIdCrearCliente);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(22, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(596, 167);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos del Cliente";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(299, 127);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(198, 20);
            this.dateTimePicker1.TabIndex = 14;
            this.dateTimePicker1.Value = new System.DateTime(2019, 8, 10, 20, 32, 14, 0);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(253, 130);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(40, 13);
            this.label14.TabIndex = 13;
            this.label14.Text = "Fecha:";
            // 
            // txtMovilCrearFactura
            // 
            this.txtMovilCrearFactura.Location = new System.Drawing.Point(94, 127);
            this.txtMovilCrearFactura.Name = "txtMovilCrearFactura";
            this.txtMovilCrearFactura.Size = new System.Drawing.Size(133, 20);
            this.txtMovilCrearFactura.TabIndex = 12;
            // 
            // cmbDistrito
            // 
            this.cmbDistrito.FormattingEnabled = true;
            this.cmbDistrito.Location = new System.Drawing.Point(450, 89);
            this.cmbDistrito.Name = "cmbDistrito";
            this.cmbDistrito.Size = new System.Drawing.Size(132, 21);
            this.cmbDistrito.TabIndex = 11;
            // 
            // cmbCantón
            // 
            this.cmbCantón.FormattingEnabled = true;
            this.cmbCantón.Location = new System.Drawing.Point(250, 89);
            this.cmbCantón.Name = "cmbCantón";
            this.cmbCantón.Size = new System.Drawing.Size(137, 21);
            this.cmbCantón.TabIndex = 10;
            // 
            // cmbProvincia
            // 
            this.cmbProvincia.FormattingEnabled = true;
            this.cmbProvincia.Location = new System.Drawing.Point(63, 89);
            this.cmbProvincia.Name = "cmbProvincia";
            this.cmbProvincia.Size = new System.Drawing.Size(125, 21);
            this.cmbProvincia.TabIndex = 9;
            // 
            // txtCorreoCrearFactura
            // 
            this.txtCorreoCrearFactura.Location = new System.Drawing.Point(109, 56);
            this.txtCorreoCrearFactura.Name = "txtCorreoCrearFactura";
            this.txtCorreoCrearFactura.Size = new System.Drawing.Size(300, 20);
            this.txtCorreoCrearFactura.TabIndex = 8;
            // 
            // txtNombreCrearFacutra
            // 
            this.txtNombreCrearFacutra.Location = new System.Drawing.Point(330, 24);
            this.txtNombreCrearFacutra.Name = "txtNombreCrearFacutra";
            this.txtNombreCrearFacutra.Size = new System.Drawing.Size(252, 20);
            this.txtNombreCrearFacutra.TabIndex = 7;
            // 
            // txtIdCrearCliente
            // 
            this.txtIdCrearCliente.Location = new System.Drawing.Point(91, 24);
            this.txtIdCrearCliente.Name = "txtIdCrearCliente";
            this.txtIdCrearCliente.Size = new System.Drawing.Size(118, 20);
            this.txtIdCrearCliente.TabIndex = 2;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(6, 130);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "Teléfono/Móvil:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(405, 92);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Distrito";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(203, 92);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(41, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Cantón";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(6, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(51, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Provincia";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(6, 59);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Correo Electrónico:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(230, 27);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(94, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Nombre Combleto:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(6, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Identificación:";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btnEnviarFactura);
            this.groupBox2.Controls.Add(this.dgvProductosAgregados);
            this.groupBox2.Controls.Add(this.btnAgregarProducto);
            this.groupBox2.Controls.Add(this.txtTotalFactura);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.txtCantidadFactura);
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.txtCategoriaFactura);
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.txtPrecioFactura);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.txtProductoFactura);
            this.groupBox2.Controls.Add(this.txtCodigoCerarFactura);
            this.groupBox2.Controls.Add(this.btnMostrarTablaFactura);
            this.groupBox2.Controls.Add(this.dgvProductos);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Location = new System.Drawing.Point(9, 185);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(634, 318);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Detalle de Compra";
            // 
            // btnEnviarFactura
            // 
            this.btnEnviarFactura.Location = new System.Drawing.Point(453, 284);
            this.btnEnviarFactura.Name = "btnEnviarFactura";
            this.btnEnviarFactura.Size = new System.Drawing.Size(103, 23);
            this.btnEnviarFactura.TabIndex = 19;
            this.btnEnviarFactura.Text = "Enviar Factura";
            this.btnEnviarFactura.UseVisualStyleBackColor = true;
            // 
            // dgvProductosAgregados
            // 
            this.dgvProductosAgregados.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductosAgregados.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Producto,
            this.Cantidad,
            this.Precio,
            this.Total});
            this.dgvProductosAgregados.Location = new System.Drawing.Point(246, 159);
            this.dgvProductosAgregados.Name = "dgvProductosAgregados";
            this.dgvProductosAgregados.RowHeadersWidth = 5;
            this.dgvProductosAgregados.Size = new System.Drawing.Size(363, 114);
            this.dgvProductosAgregados.TabIndex = 18;
            // 
            // Producto
            // 
            this.Producto.HeaderText = "PRODUCTO";
            this.Producto.Name = "Producto";
            // 
            // Cantidad
            // 
            this.Cantidad.HeaderText = "CANT.";
            this.Cantidad.Name = "Cantidad";
            this.Cantidad.Width = 60;
            // 
            // Precio
            // 
            this.Precio.HeaderText = "PRECIO";
            this.Precio.Name = "Precio";
            // 
            // Total
            // 
            this.Total.HeaderText = "TOTAL";
            this.Total.Name = "Total";
            // 
            // btnAgregarProducto
            // 
            this.btnAgregarProducto.Location = new System.Drawing.Point(347, 284);
            this.btnAgregarProducto.Name = "btnAgregarProducto";
            this.btnAgregarProducto.Size = new System.Drawing.Size(75, 23);
            this.btnAgregarProducto.TabIndex = 17;
            this.btnAgregarProducto.Text = "Agregar";
            this.btnAgregarProducto.UseVisualStyleBackColor = true;
            // 
            // txtTotalFactura
            // 
            this.txtTotalFactura.Location = new System.Drawing.Point(207, 286);
            this.txtTotalFactura.Name = "txtTotalFactura";
            this.txtTotalFactura.Size = new System.Drawing.Size(100, 20);
            this.txtTotalFactura.TabIndex = 16;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(167, 289);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(34, 13);
            this.label13.TabIndex = 15;
            this.label13.Text = "Total:";
            // 
            // txtCantidadFactura
            // 
            this.txtCantidadFactura.Location = new System.Drawing.Point(69, 257);
            this.txtCantidadFactura.Name = "txtCantidadFactura";
            this.txtCantidadFactura.Size = new System.Drawing.Size(32, 20);
            this.txtCantidadFactura.TabIndex = 14;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(6, 260);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(52, 13);
            this.label12.TabIndex = 13;
            this.label12.Text = "Cantidad:";
            // 
            // txtCategoriaFactura
            // 
            this.txtCategoriaFactura.Location = new System.Drawing.Point(69, 228);
            this.txtCategoriaFactura.Name = "txtCategoriaFactura";
            this.txtCategoriaFactura.Size = new System.Drawing.Size(108, 20);
            this.txtCategoriaFactura.TabIndex = 12;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(6, 231);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(57, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Categoría:";
            // 
            // txtPrecioFactura
            // 
            this.txtPrecioFactura.Location = new System.Drawing.Point(69, 286);
            this.txtPrecioFactura.Name = "txtPrecioFactura";
            this.txtPrecioFactura.Size = new System.Drawing.Size(75, 20);
            this.txtPrecioFactura.TabIndex = 10;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(6, 289);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(43, 13);
            this.label10.TabIndex = 9;
            this.label10.Text = "Precio: ";
            // 
            // txtProductoFactura
            // 
            this.txtProductoFactura.Location = new System.Drawing.Point(58, 195);
            this.txtProductoFactura.Name = "txtProductoFactura";
            this.txtProductoFactura.Size = new System.Drawing.Size(136, 20);
            this.txtProductoFactura.TabIndex = 8;
            // 
            // txtCodigoCerarFactura
            // 
            this.txtCodigoCerarFactura.Location = new System.Drawing.Point(58, 159);
            this.txtCodigoCerarFactura.Name = "txtCodigoCerarFactura";
            this.txtCodigoCerarFactura.Size = new System.Drawing.Size(100, 20);
            this.txtCodigoCerarFactura.TabIndex = 7;
            // 
            // btnMostrarTablaFactura
            // 
            this.btnMostrarTablaFactura.Location = new System.Drawing.Point(534, 35);
            this.btnMostrarTablaFactura.Name = "btnMostrarTablaFactura";
            this.btnMostrarTablaFactura.Size = new System.Drawing.Size(94, 23);
            this.btnMostrarTablaFactura.TabIndex = 6;
            this.btnMostrarTablaFactura.Text = "&Mostrar Prod.";
            this.btnMostrarTablaFactura.UseVisualStyleBackColor = true;
            // 
            // dgvProductos
            // 
            this.dgvProductos.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvProductos.Location = new System.Drawing.Point(6, 19);
            this.dgvProductos.Name = "dgvProductos";
            this.dgvProductos.Size = new System.Drawing.Size(522, 117);
            this.dgvProductos.TabIndex = 5;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(6, 198);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 1;
            this.label9.Text = "Producto:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(6, 162);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 13);
            this.label8.TabIndex = 0;
            this.label8.Text = "Codigo: ";
            // 
            // Pantalla_Crear_Factura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(655, 526);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Pantalla_Crear_Factura";
            this.Text = "Crear_Factura";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductosAgregados)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProductos)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txtMovilCrearFactura;
        private System.Windows.Forms.ComboBox cmbDistrito;
        private System.Windows.Forms.ComboBox cmbCantón;
        private System.Windows.Forms.ComboBox cmbProvincia;
        private System.Windows.Forms.TextBox txtCorreoCrearFactura;
        private System.Windows.Forms.TextBox txtNombreCrearFacutra;
        private System.Windows.Forms.TextBox txtIdCrearCliente;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button btnEnviarFactura;
        private System.Windows.Forms.DataGridView dgvProductosAgregados;
        private System.Windows.Forms.Button btnAgregarProducto;
        private System.Windows.Forms.TextBox txtTotalFactura;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtCantidadFactura;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtCategoriaFactura;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtPrecioFactura;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txtProductoFactura;
        private System.Windows.Forms.TextBox txtCodigoCerarFactura;
        private System.Windows.Forms.Button btnMostrarTablaFactura;
        private System.Windows.Forms.DataGridView dgvProductos;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.DataGridViewTextBoxColumn Producto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn Precio;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
    }
}