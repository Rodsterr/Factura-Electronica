﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Capa_Presentación
{
    class Conexion
    {
        SqlConnection cn;
        SqlCommand cm;
        SqlDataAdapter da;
        DataTable dt;

        public Conexion()
        {
           
                cn = new SqlConnection("data source=RODSTERR;initial catalog=FACTURACION;integrated security=True");
                cn.Open();
            MessageBox.Show("Conexion establecida");
        }

        public String InsertarUsuario(String nombre, String correo, String contraseña)
        {
            string mensaje = "Datos Insertados";
            try
            {
                cm = new SqlCommand("INSERT INTO USUARIO(NOM_USUARIO,CORREO_USUARIO,CONTRASEÑA)VALUES(" + nombre + ", '" + correo + "', " + contraseña + "')", cn);
                cm.ExecuteNonQuery();
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);
            }
            catch(Exception e)
            {
                mensaje = "No se insertaron sus datos" + e.ToString();
            }

            return mensaje;
        }

        public void ingresar(String correo, String contraseña)
        {
            try
            {
                cm = new SqlCommand("SELECT CORREO_USUARIO,CONTRASEÑA FROM USUARIO WHERE CORREO_USUARIO= @correo AND CONTRASEÑA=@contraseña");
                cm.Parameters.AddWithValue("correo", correo);
                cm.Parameters.AddWithValue("contraseña", contraseña);
                da = new SqlDataAdapter(cm);
                dt = new DataTable();
                da.Fill(dt);

                
            }
            catch (Exception e)
            {
                MessageBox.Show (e+"Correo o Contraseña incorrectos");
            }
            
        }
    }
}
