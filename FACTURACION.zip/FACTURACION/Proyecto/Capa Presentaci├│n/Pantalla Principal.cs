﻿using System;
using System.Windows.Forms;

namespace Capa_Presentación
{
    public partial class Pantalla_Principal : Form
    {
        public Pantalla_Principal()
        {
            InitializeComponent();
        }

        private void ToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            Pantalla_Crear_Factura.ActiveForm.Show();
        }

        private void ReporteDeFacturasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PantallaReportes.ActiveForm.Show();
        }

        private void ReporteDeClientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PantallaReportes.ActiveForm.Show();
        }
    }
}
