﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Capa_Presentación
{
    public partial class PantallaRegistrarse : Form
    {
        Conexion co = new Conexion();
        public PantallaRegistrarse()
        {
            InitializeComponent();
        }

        private void InicioSesión_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            PantallaInicioSesion PI = new PantallaInicioSesion();
            PI.Show();
     
        }

        private void BtnCancelaRegistrar_Click(object sender, EventArgs e)
        {
            txtNombreRegistro.Clear();
            txtCorreoRegistro.Clear();
            txtPassword.Clear();

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnRegistrar_Click(object sender, EventArgs e)
        {
            co.InsertarUsuario(txtNombreRegistro.Text, txtCorreoRegistro.Text, txtPassword.Text);
        }
    }
}
