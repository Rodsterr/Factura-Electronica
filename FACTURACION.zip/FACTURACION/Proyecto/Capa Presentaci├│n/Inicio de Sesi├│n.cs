﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Capa_Presentación
{
    public partial class PantallaInicioSesion : Form
    {
        Conexion co = new Conexion();
        public PantallaInicioSesion()
        {
            InitializeComponent();
            

        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void Registrarse_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            PantallaRegistrarse PR = new PantallaRegistrarse();
            PR.Show();
            
        }

        private void BtnSalirLogin_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnInicioSecionLogin_Click(object sender, EventArgs e)
        {
            co.ingresar(txtCorreoLogin.Text, txtPasswordLogin.Text);
            this.Hide();
            Pantalla_Principal PP = new Pantalla_Principal();
            PP.Show();


        }
    }
}
